def test_function():
    """Prints a simple statement."""
    print("You manually installed the toy_pkg example! Well done!")
